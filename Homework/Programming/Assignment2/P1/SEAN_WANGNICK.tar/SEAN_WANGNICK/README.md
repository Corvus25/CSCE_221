# Assignment 2 P1 – Doubly Linked List

* Sean Wangnick
* 427003718
* CSCE 221-505
* swangnick
* swangnick@tamu.edu

### Aggie Honor Statement
I certify that I have listed all the sources that I used to develop the solutions and code to the submitted work.
On my honor as an Aggie, I have neither given nor received any unauthorized help on this academic work.

Sean Wangnick - 2/17/2020

### Resources
- Some "Stack Overflow" sites to reference some syntactical C++ stuff.
- Previous work from CSCE 121 DLL homework
- Dr. Leyk's DLL slides

### Known Issues
- N/A

### Description


### Testing


#### Exceptions
